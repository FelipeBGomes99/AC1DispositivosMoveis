package com.facens.ac2_223868;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText edtNome, edtDiretor, edtLancamento, edtGenero;
    RatingBar ratingBar;
    CheckBox checkTrue, checkFalse;
    Button btnSalvar;
    ListView listViewFilmes;

    BancoHelper bancoHelper;
    ArrayAdapter<String> adapter;
    ArrayList<String> listaFilmes;
    ArrayList<Integer> listaIds;


    public void carregarFilmes() {
        Cursor cursor = bancoHelper.listarFilmes();
        listaFilmes = new ArrayList<>();
        listaIds = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(0);
                String nome = cursor.getString(1);
                String diretor = cursor.getString(2);
                int ano = cursor.getInt(3);
                String genero = cursor.getString(4);
                int nota = cursor.getInt(5);
                boolean assistido = cursor.getInt(6) == 1;

                listaFilmes.add(nome + " | " + ano + " | " + genero + " | Nota: " + nota);
                listaIds.add(id);
            } while (cursor.moveToNext());
        }

        cursor.close();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaFilmes);
        listViewFilmes.setAdapter(adapter);
    }

    public void salvarFilme() {
        String titulo = edtNome.getText().toString();
        String diretor = edtDiretor.getText().toString();
        String anoStr = edtLancamento.getText().toString();
        String genero = edtGenero.getText().toString();
        int nota = (int) ratingBar.getRating();


        Boolean assistido = null;
        if (checkTrue.isChecked()) {
            assistido = true;
        } else if (checkFalse.isChecked()) {
            assistido = false;
        }


        if (!titulo.isEmpty() && !anoStr.isEmpty() && !genero.isEmpty() && assistido != null) {
            int ano = Integer.parseInt(anoStr);
            long resultado = bancoHelper.inserirFilme(titulo, diretor, ano, genero, nota, assistido);

            if (resultado != -1) {
                Toast.makeText(this, "Filme salvo!", Toast.LENGTH_SHORT).show();


                edtNome.setText("");
                edtDiretor.setText("");
                edtLancamento.setText("");
                edtGenero.setText("");
                ratingBar.setRating(0);
                checkTrue.setChecked(false);
                checkFalse.setChecked(false);

                carregarFilmes();
            } else {
                Toast.makeText(this, "Erro ao salvar!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Preencha todos os campos e selecione se já assistiu!", Toast.LENGTH_SHORT).show();
        }
    }

    public void atualizarFilme(int filmeId) {
        String titulo = edtNome.getText().toString();
        String diretor = edtDiretor.getText().toString();
        String anoStr = edtLancamento.getText().toString();
        String genero = edtGenero.getText().toString();
        int nota = (int) ratingBar.getRating();


        Boolean assistido = null;
        if (checkTrue.isChecked()) {
            assistido = true;
        } else if (checkFalse.isChecked()) {
            assistido = false;
        }


        if (!titulo.isEmpty() && !anoStr.isEmpty() && !genero.isEmpty() && assistido != null) {
            int ano = Integer.parseInt(anoStr);
            int resultado = bancoHelper.atualizarFilme(filmeId, titulo, diretor, ano, genero, nota, assistido);

            if (resultado > 0) {
                Toast.makeText(this, "Filme atualizado!", Toast.LENGTH_SHORT).show();


                edtNome.setText("");
                edtDiretor.setText("");
                edtLancamento.setText("");
                edtGenero.setText("");
                ratingBar.setRating(0);
                checkTrue.setChecked(false);
                checkFalse.setChecked(false);

                btnSalvar.setText("Salvar");
                carregarFilmes();
                btnSalvar.setOnClickListener(v -> salvarFilme());
            } else {
                Toast.makeText(this, "Erro ao atualizar!", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "Preencha todos os campos e selecione se já assistiu!", Toast.LENGTH_SHORT).show();
        }
    }

    public void configurarCliqueCurto() {
        listViewFilmes.setOnItemClickListener((parent, view, position, id) -> {

            int filmeId = listaIds.get(position);


            String[] dados = listaFilmes.get(position).split(" - ");
            String titulo = dados[1];
            String ano = dados[2];
            String notaStr = dados[3];
            String genero = dados[4];


            edtNome.setText(titulo);
            edtLancamento.setText(ano);
            edtGenero.setText(genero);
            ratingBar.setRating(Float.parseFloat(notaStr));


            Cursor cursor = bancoHelper.listarFilmes();
            if (cursor != null && cursor.moveToFirst()) {
                int indexId = cursor.getColumnIndex("id");
                int indexDiretor = cursor.getColumnIndex("diretor");
                int indexAssistido = cursor.getColumnIndex("assistido");

                do {
                    if (cursor.getInt(indexId) == filmeId) {
                        edtDiretor.setText(cursor.getString(indexDiretor));
                        int assistido = cursor.getInt(indexAssistido);
                        checkTrue.setChecked(assistido == 1);
                        checkFalse.setChecked(assistido == 0);
                        break;
                    }
                } while (cursor.moveToNext());
                cursor.close();
            }


            btnSalvar.setText("Atualizar");
            btnSalvar.setOnClickListener(v -> atualizarFilme(filmeId));
        });
    }



    public void configurarCliqueLongo() {
        listViewFilmes.setOnItemLongClickListener((parent, view, position, id) -> {
            int filmeId = listaIds.get(position);
            int deletado = bancoHelper.excluirFilme(filmeId);

            if (deletado > 0) {
                Toast.makeText(this, "Filme excluído!", Toast.LENGTH_SHORT).show();
                carregarFilmes();
            } else {
                Toast.makeText(this, "Erro ao excluir filme!", Toast.LENGTH_SHORT).show();
            }

            return true;
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        try {

            edtNome = findViewById(R.id.edtNome);
            edtDiretor = findViewById(R.id.edtDiretor);
            edtLancamento = findViewById(R.id.edtLancamento);
            edtGenero = findViewById(R.id.edtGenero);
            ratingBar = findViewById(R.id.ratingBar);
            checkTrue = findViewById(R.id.checkTrue);
            checkFalse = findViewById(R.id.checkFalse);

            btnSalvar = findViewById(R.id.btnSalvar);


            listViewFilmes = findViewById(R.id.ListFilmes);


            bancoHelper = new BancoHelper(this);

            btnSalvar.setOnClickListener(v -> salvarFilme());
            configurarCliqueCurto();
            configurarCliqueLongo();
            carregarFilmes();



        }catch (Exception e)
        {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }








    }
}