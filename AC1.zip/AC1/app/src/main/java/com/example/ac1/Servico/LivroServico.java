package com.example.ac1.Servico;

import com.example.ac1.Modelo.Livro;
import com.example.ac1.Repositorio.LivroRepo;

import java.util.List;

public class LivroServico {

    LivroRepo livros;

    public LivroServico() {
        this.livros = new LivroRepo();
    }

    public Livro adicionarLivro(String livro, String autor, boolean status){
        Livro livroadicionado = new Livro();
        livroadicionado.setAutor(autor);
        livroadicionado.setTitulo(livro);
        livroadicionado.setTerminado(status);

        livros.adicionarLivro(livroadicionado);

        return livroadicionado;
    }

    public List<Livro> mostrarLivros() {
        return livros.getLivros();
    }
}
