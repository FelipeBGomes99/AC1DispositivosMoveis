package com.example.ac1.Repositorio;

import com.example.ac1.Modelo.Livro;

import java.util.ArrayList;
import java.util.List;

public class LivroRepo {

    public List<Livro> livros;

    public LivroRepo(){
        this.livros = new ArrayList<>();
    }

    public List<Livro> getLivros() {
        return livros;
    }

    public void setLivros(List<Livro> livros) {
        this.livros = livros;
    }

    public void adicionarLivro(Livro livro) {
        livros.add(livro);
    }
}
