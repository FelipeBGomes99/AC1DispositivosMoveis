package com.example.ac1;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.ac1.Modelo.Livro;
import com.example.ac1.Repositorio.LivroRepo;
import com.example.ac1.Servico.LivroServico;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    LivroServico livroServico = new LivroServico();
    TextView tituloCadastro;
    TextView tituloLabel;
    TextView autorLabel;
    TextView radioLabel;
    EditText tituloInput;
    EditText autorInput;
    RadioGroup escolhasStatus;
    Button enviarBtn;
    LinearLayout layoutLivros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tituloCadastro = findViewById(R.id.tituloCadastro);
        tituloCadastro.setText("Cadastre um livro novo!");

        tituloLabel = findViewById(R.id.tituloLabel);
        tituloLabel.setText("titulo:");

        autorLabel = findViewById(R.id.autorLabel);
        autorLabel.setText("autor:");

        radioLabel = findViewById(R.id.radioLabel);
        radioLabel.setText("status:");

        tituloInput = findViewById(R.id.tituloInput);
        tituloInput.setHint("titulo...");

        autorInput = findViewById(R.id.autorInput);
        tituloInput.setHint("autor...");

        escolhasStatus = findViewById(R.id.radioLayout);

        layoutLivros = findViewById(R.id.livrosLayout);

        enviarBtn = findViewById(R.id.adicionarLivro);
        enviarBtn.setOnClickListener(ev -> {
            String titulo = tituloInput.getText().toString();
            String autor = autorInput.getText().toString();
            boolean statuslivro;

            int idSelecionado = escolhasStatus.getCheckedRadioButtonId();
            RadioButton radioSelecionado = findViewById(idSelecionado);

            if(radioSelecionado.getText().toString().equals("terminado")){
                statuslivro = true;
            } else {
                statuslivro = false;
            }
            Livro livroRecemAdicionado = livroServico.adicionarLivro(titulo,autor,statuslivro);

                TextView textView = new TextView(this);
                String texto = "Livro: "+ livroRecemAdicionado.getTitulo() + "autor: " + livroRecemAdicionado.getAutor() + "terminado: " + livroRecemAdicionado.getTerminado();
                textView.setText(texto);
                textView.setPadding(8, 8, 8, 8);
                layoutLivros.addView(textView);

        });

    }
}